const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }, // Lưu chuỗi đã băm, KHÔNG lưu plaintext
    fullName: { type: String }
});

module.exports = mongoose.model('User', userSchema);