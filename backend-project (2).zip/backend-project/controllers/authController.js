const User = require('../models/User');
const { hashPassword, comparePassword } = require('../utils/bcryptHelper');

// 1. Đăng ký (Băm mật khẩu)
const register = async (req, res) => {
    try {
        const { email, password, fullName } = req.body;
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email đã tồn tại!' });
        }

        const hashedPassword = await hashPassword(password);

        const newUser = new User({
            email,
            password: hashedPassword,
            fullName
        });

        await newUser.save();
        return res.status(201).json({ message: 'Đăng ký thành công!' });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

// 2. Đăng nhập (Kiểm tra mật khẩu & Rà soát API không trả password)
const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Sai email hoặc mật khẩu!' });
        }

        const isMatch = await comparePassword(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Sai email hoặc mật khẩu!' });
        }

        // Rà soát API: Xóa trường password trước khi trả về cho client
        const userResponse = user.toObject();
        delete userResponse.password;

        return res.status(200).json({
            message: 'Đăng nhập thành công!',
            user: userResponse
        });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

module.exports = { register, login };