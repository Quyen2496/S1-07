const express = require('express');
const mongoose = require('mongoose');
const crypto = require('crypto');
const { register, login } = require('./controllers/authController');

const app = express();
app.use(express.json());

// Routes API Auth
app.post('/api/register', register);
app.post('/api/login', login);

// Lưu vết lịch sử đặt phòng theo IP (S2-07)
const bookingLogs = {};

// Dữ liệu mẫu giả định cho Báo cáo Doanh thu (S4-07)
const sampleClosedBookings = [
  { id: 'BK01', date: '2026-09-24', roomType: 'Deluxe', roomFee: 1000000, surcharge: 200000, nights: 1 },
  { id: 'BK02', date: '2026-09-24', roomType: 'Standard', roomFee: 500000, surcharge: 50000, nights: 1 },
  { id: 'BK03', date: '2026-09-25', roomType: 'VIP', roomFee: 2000000, surcharge: 300000, nights: 2 },
  { id: 'BK04', date: '2026-09-25', roomType: 'Deluxe', roomFee: 1200000, surcharge: 100000, nights: 1 },
  // Cùng kỳ liền trước (Ví dụ kỳ trước đó)
  { id: 'BK05', date: '2026-09-22', roomType: 'Standard', roomFee: 1500000, surcharge: 100000, nights: 2 }
];

// ==========================================
// 1. API Gửi yêu cầu đặt phòng (S2-07)
// ==========================================
app.post('/api/bookings', (req, res) => {
  const { fullName, phone, email, guestCount, note, agreedPolicy, roomId } = req.body;
  const userIp = req.ip || req.socket.remoteAddress;

  if (!agreedPolicy) return res.status(400).json({ error: true, message: "Bạn phải tích chọn xác nhận đã đọc chính sách hủy!" });
  if (!fullName || !phone || !email || !guestCount) return res.status(400).json({ error: true, message: "Vui lòng điền đầy đủ thông tin!" });

  const phoneRegex = /(84|0[3|5|7|8|9])+([0-9]{8})\b/;
  if (!phoneRegex.test(phone)) return res.status(400).json({ error: true, message: "Số điện thoại không hợp lệ!" });

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) return res.status(400).json({ error: true, message: "Email không hợp lệ!" });

  const now = Date.now();
  if (!bookingLogs[userIp]) bookingLogs[userIp] = [];
  bookingLogs[userIp] = bookingLogs[userIp].filter(time => now - time < 3600000);

  if (bookingLogs[userIp].length >= 5) {
    return res.status(429).json({ error: true, message: "Vượt quá giới hạn 5 lượt đặt phòng/giờ!" });
  }

  if (roomId === 'ROOM_FULL') {
    return res.status(409).json({ error: true, message: "Khoảng ngày vừa bị người khác đặt mất!", keepData: true });
  }

  bookingLogs[userIp].push(now);

  const bookingCode = crypto.randomBytes(4).toString('hex').toUpperCase();
  const expiresAt = new Date(now + 24 * 60 * 60 * 1000);

  res.status(201).json({
    success: true,
    message: "Gửi yêu cầu đặt phòng thành công!",
    booking: { bookingCode, status: "Chờ xác nhận", expiresAt, customerInfo: { fullName, phone, email, guestCount, note } }
  });
});

// ==========================================
// 2. API Lễ tân làm thủ tục nhận phòng (S3-07)
// ==========================================
app.post('/api/check-in', (req, res) => {
  const { bookingId, bookingStatus, roomStatus, primaryGuest, accompanyingGuests, forceCheckIn } = req.body;

  if (bookingStatus !== 'Đã xác nhận') return res.status(400).json({ error: true, message: "Booking chưa được xác nhận!" });
  if (roomStatus !== 'Trống sạch') return res.status(400).json({ error: true, message: "Phòng chưa ở trạng thái Trống sạch!" });
  if (!primaryGuest || !primaryGuest.fullName || !primaryGuest.idCard) {
    return res.status(400).json({ error: true, message: "Bắt buộc nhập tên và giấy tờ tuỳ thân khách đứng tên!" });
  }

  const now = Date.now();
  const options = { timeZone: 'Asia/Ho_Chi_Minh', hour12: false, hour: '2-digit' };
  const currentHour = parseInt(new Intl.DateTimeFormat('en-US', options).format(now), 10);

  if (currentHour < 14 && !forceCheckIn) {
    return res.status(200).json({
      warning: true,
      isEarlyCheckIn: true,
      message: "Khách nhận phòng trước 14:00 (Nhận phòng sớm). Bạn có muốn tiếp tục?",
      requireConfirmation: true
    });
  }

  const actualCheckInTime = new Date().toLocaleString("en-US", { timeZone: "Asia/Ho_Chi_Minh" });

  res.status(200).json({
    success: true,
    message: "Làm thủ tục nhận phòng thành công!",
    data: { bookingId, bookingStatus: "Đang lưu trú", roomStatus: "Đang ở", actualCheckInTime, primaryGuest }
  });
});

// ==========================================
// 3. API Xem Báo cáo Doanh thu (S4-07)
// ==========================================
app.get('/api/revenue-report', (req, res) => {
  const { role, startDate, endDate } = req.query; // role: 'owner' hoặc 'receptionist'

  // Hôm nay (định dạng YYYY-MM-DD theo Asia/Ho_Chi_Minh)
  const todayStr = new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Ho_Chi_Minh' });

  // AC 4: Phân quyền Lễ tân chỉ xem được ngày hiện tại
  if (role === 'receptionist') {
    if ((startDate && startDate !== todayStr) || (endDate && endDate !== todayStr)) {
      return res.status(403).json({
        error: true,
        message: "Lễ tân chỉ có quyền xem doanh thu của ngày hiện tại, không thể xem toàn kỳ!"
      });
    }
  }

  // AC 1: Chỉ tính từ các booking đã đóng & tách riêng tiền phòng + phụ thu
  const queryStart = (role === 'receptionist') ? todayStr : (startDate || '2026-09-01');
  const queryEnd = (role === 'receptionist') ? todayStr : (endDate || '2026-09-30');

  const filteredBookings = sampleClosedBookings.filter(b => b.date >= queryStart && b.date <= queryEnd);

  let totalRoomFee = 0;
  let totalSurcharge = 0;
  let totalNights = 0;
  const byRoomType = {};
  const byDate = {};

  filteredBookings.forEach(b => {
    totalRoomFee += b.roomFee;
    totalSurcharge += b.surcharge;
    totalNights += b.nights;

    // Doanh thu theo loại phòng
    if (!byRoomType[b.roomType]) byRoomType[b.roomType] = { roomFee: 0, surcharge: 0, total: 0 };
    byRoomType[b.roomType].roomFee += b.roomFee;
    byRoomType[b.roomType].surcharge += b.surcharge;
    byRoomType[b.roomType].total += (b.roomFee + b.surcharge);

    // Doanh thu theo ngày
    if (!byDate[b.date]) byDate[b.date] = { roomFee: 0, surcharge: 0, total: 0 };
    byDate[b.date].roomFee += b.roomFee;
    byDate[b.date].surcharge += b.surcharge;
    byDate[b.date].total += (b.roomFee + b.surcharge);
  });

  const totalRevenue = totalRoomFee + totalSurcharge;
  const bookingCount = filteredBookings.length;

  // AC 2: Giá bán trung bình mỗi đêm (ADR)
  const averageDailyRate = totalNights > 0 ? Math.round(totalRevenue / totalNights) : 0;

  // AC 3: So sánh với cùng kỳ liền trước & tính % chênh lệch (Ví dụ giả định kỳ trước)
  const previousPeriodRevenue = 1600000; // Giả định kỳ trước đạt 1.6M
  const diffAmount = totalRevenue - previousPeriodRevenue;
  const percentageChange = previousPeriodRevenue > 0 
    ? ((diffAmount / previousPeriodRevenue) * 100).toFixed(2) + '%' 
    : '0%';

  res.status(200).json({
    success: true,
    role,
    period: { startDate: queryStart, endDate: queryEnd },
    summary: {
      totalRevenue,       // Tổng doanh thu
      totalRoomFee,      // Tiền phòng (tách riêng)
      totalSurcharge,    // Tiền phụ thu (tách riêng)
      bookingCount,      // Số booking
      averageDailyRate,  // Giá bán trung bình mỗi đêm
      comparisonWithPreviousPeriod: {
        previousRevenue: previousPeriodRevenue,
        difference: diffAmount,
        percentageChange // Mức chênh lệch theo %
      }
    },
    breakdownByRoomType: byRoomType, // Tách theo loại phòng
    breakdownByDate: byDate         // Tách theo ngày
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server đang chạy tại http://localhost:${PORT}`);
});